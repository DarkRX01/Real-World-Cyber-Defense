Cyber Defense - Windows Portable Edition
==========================================

INSTALLATION:
-------------
1. Extract this entire ZIP file to a folder of your choice
2. Go into the CyberDefense folder
3. Run "CyberDefense.exe"

IMPORTANT:
----------
⚠️  DO NOT move CyberDefense.exe out of its folder!
⚠️  Keep all files together in the same folder

The application needs all the DLL files and dependencies
that are included in this folder.

FIRST RUN:
----------
If Windows SmartScreen shows a warning:
  1. Click "More info"
  2. Click "Run anyway"

If your antivirus blocks it:
  - This is a false positive (common for new unsigned apps)
  - Add an exception for the CyberDefense folder

FEATURES:
---------
✓ Real-time threat detection
✓ Clipboard URL monitoring
✓ Tracker blocking
✓ Phishing detection
✓ Modern GUI dashboard
✓ System tray integration

TROUBLESHOOTING:
----------------
If the app doesn't start:
  1. Make sure all files are extracted together
  2. Check if antivirus is blocking it
  3. Try running as administrator
  4. Check logs at: %APPDATA%\.cyber-defense\logs\

SYSTEM REQUIREMENTS:
--------------------
- Windows 10 or later
- 100 MB free disk space
- Internet connection (optional, for updates)

For support and updates:
https://github.com/DarkRX01/Real-World-Cyber-Defense
