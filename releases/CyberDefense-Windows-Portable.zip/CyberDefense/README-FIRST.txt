========================================
  CYBER DEFENSE - Real-World Security
========================================

HOW TO RUN (easy):
------------------
  Double-click:  Run Cyber Defense.bat

  Or double-click:  CyberDefense.exe

  IMPORTANT: Use the .bat or .exe above. Do NOT run "python app_main.py"
  from this folder (this folder does not contain Python scripts).

  The app will appear in your system tray (near the clock).
  Double-click the tray icon to open the main window.


FIRST TIME?
-----------
  - By default the window does NOT open on startup (tray only).
  - Right-click the tray icon -> "Show" to open the window.
  - Go to Settings to enable/disable features and save.


IF WINDOWS WARNS (SmartScreen):
-------------------------------
  1. Click "More info"
  2. Click "Run anyway"


IF YOUR ANTIVIRUS BLOCKS IT:
----------------------------
  This app is open source and safe. Unsigned apps are often flagged.
  Add an exception for this folder, or build from source (see GitHub).


KEEP ALL FILES TOGETHER:
------------------------
  Do not move only CyberDefense.exe. Keep the whole folder;
  the app needs the other files in this directory.


Need help?  https://github.com/DarkRX01/Real-World-Cyber-Defense
========================================
